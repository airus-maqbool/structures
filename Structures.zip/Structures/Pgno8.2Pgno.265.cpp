#include <iostream>
using namespace std;
int main()
{
    struct dateOfBirth
    {
       int day, year, month;
    };
    dateOfBirth b;
    cout<<"Enter your day of birth: ";
    cin>>b.day;
    cout<<"Enter your month of birth: ";
    cin>>b.month;
    cout<<"Enter your year of birth: ";
    cin>>b.year;
    cout<<"Your date of birth is shown below: "<<endl;
    cout<<b.day<<"/"<<b.month<<"/"<<b.year;
    return 0;
}
