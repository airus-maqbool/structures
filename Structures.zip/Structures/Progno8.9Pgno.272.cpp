#include <iostream>
using namespace std;
int main()
{ int mostcostlybook=0, indexOfmostcostlyBook;
  struct bookinfo
  { 
    int id, pages, price;
  };
  bookinfo book[5];
                         /*entering values in array (loop first access array using i and then fill all its structure's members
                           if condition is used to get the most costly book and its index so that it can be accessed outside the loop.*/
                         
  for (int i=0; i<5; i++)
  {
    cout<<"Enter details of book "<<i+1<<": "<<endl;
    cout<<"Enter Book id: ";
    cin>>book[i].id;
    cout<<"Enter pages: ";
    cin>>book[i].pages;
    cout<<"Enter price:";
    cin>>book[i].price;
    if (book[i].price>mostcostlybook)
    {
      mostcostlybook=book[i].price;
      indexOfmostcostlyBook=i;
    }
  }
                         //displaying details of most costly book
                         
  cout<<"The details of most costly book is given below: "<<endl;
  cout<<"Book id: "<<book[indexOfmostcostlyBook].id<<endl;
  cout<<"Pages: "<<book[indexOfmostcostlyBook].pages<<endl;
  cout<<"Price: "<<book[indexOfmostcostlyBook].price<<endl;
  return 0;    
}
