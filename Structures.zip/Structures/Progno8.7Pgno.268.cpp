#include <iostream>
using namespace std;
int main()
{  
  struct studentInfo
  {
    int marks;
    char grade;
  };
  studentInfo Usman, Ahmad;
  cout<<"Enter marks of Usman: ";
  cin>>Usman.marks;
  cout<<"Enter grade of Usman: ";
  cin>>Usman.grade;
  Ahmad=Usman;
  cout<<"Usman\'s information is shown below: "<<endl;
  cout<<"Marks: "<<Usman.marks<<endl;
  cout<<"Grade: "<<Usman.grade<<endl;
  cout<<"Ahmad\'s information is shown below: "<<endl;
  cout<<"Marks: "<<Ahmad.marks<<endl;
  cout<<"Grade: "<<Ahmad.grade<<endl;
  return 0;
}
