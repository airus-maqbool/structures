#include <iostream>
using namespace std;
int main()
{ 
  struct date
  {
    int day, month, year;
  };
  struct phonebook
  {
    char name[10], city[10];     //char type array to store name
    int telephone;
    date x;
  };
  phonebook p1;
  cout<<"Enter your name: ";
  cin>>p1.name;                                 //only name of array to access overall array (name[10])
  cout<<"Enter your city name: ";
  cin>>p1.city;
  cout<<"Enter your telephone number: ";
  cin>>p1.telephone;
  cout<<"Enter day of your birth: ";
  cin>>p1.x.day;
  cout<<"Enter month of your birth: ";
  cin>>p1.x.month;
  cout<<"Enter year of your birth: ";
  cin>>p1.x.year;
  cout<<"Your entered details are as follows: "<<endl;
  cout<<"Name: "<<p1.name<<endl;
  cout<<"City: "<<p1.city<<endl;
  cout<<"Telephone: "<<p1.telephone<<endl;
  cout<<"Date of birth: "<<p1.x.day<<"/"<<p1.x.month<<"/"<<p1.x.year<<endl;
  return 0;    
}
