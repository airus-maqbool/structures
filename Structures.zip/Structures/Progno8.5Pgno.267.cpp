#include <iostream>
using namespace std;
int main()
{
   struct phonenum
   {
     int ncode, acode, number;  
   };
   phonenum p1={92, 31, 3515410};
   phonenum p2;
   cout<<"Enter your phone number\'s National code: ";
   cin>>p2.ncode;
   cout<<"Enter your phone number\'s Area code: ";
   cin>>p2.acode;
   cout<<"Enter your phone number: ";
   cin>>p2.number;
   cout<<"-------------------------------------"<<endl;
   cout<<"Phone number details for person1 are shown below: "<<endl;
   cout<<"+"<<p1.ncode<<"_"<<p1.acode<<"_"<<p1.number<<endl;
   cout<<"Phone number details for person2 are shown below: "<<endl;
    cout<<"+"<<p2.ncode<<"_"<<p2.acode<<"_"<<p2.number<<endl;
  return 0;
}
