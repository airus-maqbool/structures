#include <iostream>
using namespace std;
int main()
{ 
  struct Dimensions 
  {
    float length, width;
  };
  struct Result 
  {
    float area, perimeter;  
  };
  struct Rectangle 
  {
    Dimensions x;
    Result y;
  };
  Rectangle z;
  cout<<"Enter length of rectangle: ";
  cin>>z.x.length;
  cout<<"Enter width of rectangle: ";
  cin>>z.x.width;
  z.y.area=z.x.length*z.x.width;
  z.y.perimeter=2*z.x.length+z.x.width;
  cout<<"Rectangl\'s area: "<<z.y.area<<endl;
  cout<<"Rectangl\'s perimeter: "<<z.y.perimeter<<endl;
  return 0;    
}
