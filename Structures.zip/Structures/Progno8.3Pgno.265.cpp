#include <iostream>
using namespace std;
int main()
{
  struct bookinfo
  {
      int id, price, pages;
  };
  bookinfo book1, book2;
  cout<<"Enter Id, price and pages of book1 respectively: "<<endl;
  cin>>book1.id>>book1.price>>book1.pages;
  cout<<"Enter Id, price and pages of book2 respectively: "<<endl;
  cin>>book2.id>>book2.price>>book2.pages;
  if (book1.price>book2.price)
  {
    cout<<"The details of most costly book is given below: "<<endl;
    cout<<"Id: "<<book1.id<<endl;
    cout<<"Price: "<<book1.price<<endl;
    cout<<"Number of pages: "<<book1.pages<<endl;
  }
  else
  {
    cout<<"The details of most costly book is given below: "<<endl;
    cout<<"Id: "<<book2.id<<endl;
    cout<<"Price: "<<book2.price<<endl;
    cout<<"Number of pages: "<<book2.pages<<endl;
  }
  return 0;
}
