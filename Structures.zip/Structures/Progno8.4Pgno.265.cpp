#include <iostream>
using namespace std;
int main()
{
   struct employInfo
   {
     int id, salary;  
   };
   employInfo e1={200, 25000};
   cout<<"Employ ID: "<<e1.id<<endl;
   cout<<"Employ salary: "<<e1.salary<<endl;
  return 0;
}
