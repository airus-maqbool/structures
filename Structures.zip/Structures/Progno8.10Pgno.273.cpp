#include <iostream>
using namespace std;
int main()
{ 
  struct Result
  {
    int marks;
    char grade;
  };
  struct Record
  {
    int rollno;
    Result x;
  };
  Record num;
  cout<<"Enter roll number: ";
  cin>>num.rollno;
  cout<<"Enter marks: ";
  cin>>num.x.marks;
  cout<<"Enter grade: ";
  cin>>num.x.grade;
  cout<<"Your entered details are as follows: "<<endl;
  cout<<"Roll number: "<<num.rollno<<endl;
  cout<<"Marks: "<<num.x.marks<<endl;
  cout<<"Grade: "<<num.x.grade<<endl;
  return 0;    
}
