#include <iostream>
using namespace std;
int main()
{  
  struct studentInfo
  {  
    char name[10];
    int rollno, marks[5];
  };
  studentInfo p1;
  cout<<"Enter your name: ";
  cin>>p1.name;  //to access overall array only use array name (not its indexes) , use indexes to access individual array element
  cout<<"Enter your roll numnber: ";
  cin>>p1.rollno;
  //Getting marks of 5 subjects in array marks using loop and finding average
  float sum=0;
  for (int i=0; i<5; i++)
  {
    cout<<"Enter marks of subject "<<i+1<<": ";
    cin>>p1.marks[i];
    sum+=p1.marks[i]; //sum to calculate average
  }
  cout<<"Your information is shown below: "<<endl;
  cout<<"Name: "<<p1.name<<endl;
  cout<<"Roll number: "<<p1.rollno<<endl;
  cout<<"Marks of all subject are given as below: "<<endl;
  for (int i=0; i<5; i++)
  {
      cout<<"Subject "<<i+1<<": "<<p1.marks[i]<<endl;
  }
  cout<<"Average of marks: "<<sum/5;
  return 0;
}
